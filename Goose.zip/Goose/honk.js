const Discord = require('discord.js');
const client = new Discord.Client();

Channel1 = `channel id here`

client.on('ready', () => {
  setInterval(() => {
    client.channels.cache.get(Channel1).messages.fetch({ limit: 1 }).then(messages => {
      let lastMessage = messages.first();   
      if (lastMessage.author.tag !== "DiscordGoose#4492") {
    getRandomInt2 = Math.floor(Math.random() * 2);    
  
    if (getRandomInt2 === 1) {
        getRandomInt3 = Math.floor(Math.random() * 6); 
          if (getRandomInt3 === 2) {
            client.channels.cache.get(Channel1).send("honk!");
          } else if (getRandomInt3 === 3) {
            client.channels.cache.get(Channel1).send("hjonk!");
          } else if (getRandomInt3 === 4) {
            client.channels.cache.get(Channel1).send("bajhunskst, honk..");
        } else if (getRandomInt3 === 5) {
            client.channels.cache.get(Channel1).send("nsfdafdsaafsdjlasdas").then((m) => 
            setTimeout(() => {
             m.edit("sorry, hard to type with feet")
           }, 5000));
          } else {
            getRandomInt4 = Math.floor(Math.random() * 14); 
            if (getRandomInt4 === 1) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/1.png"] });
            } else if (getRandomInt4 === 2) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/2.png"] });
            } else if (getRandomInt4 === 3) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/3.png"] });
            } else if (getRandomInt4 === 4) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/4.png"] });
            } else if (getRandomInt4 === 5) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/5.png"] });
            } else if (getRandomInt4 === 6) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/6.gif"] });
            } else if (getRandomInt4 === 7) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/7.png"] });
            } else if (getRandomInt4 === 8) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/8.png"] });
            } else if (getRandomInt4 === 9) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/9.png"] });
            } else if (getRandomInt4 === 10) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/10.png"] });
            } else if (getRandomInt4 === 11) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/11.png"] });
            } else if (getRandomInt4 === 12) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/12.png"] });
            } else if (getRandomInt4 === 13) {
                client.channels.cache.get(Channel1).send(" ⁣ ⁣", { files: ["./resources/13.png"] });
            }
          }
    }
  }
})
    return;
  }, 5 * 60000); 
});

  

client.login('token here');